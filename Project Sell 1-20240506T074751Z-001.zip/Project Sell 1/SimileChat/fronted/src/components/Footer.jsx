import { useState } from 'react';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Footer = () => {
  const [email, setEmail] = useState('');

  const handleSubscribe = (e) => {
    e.preventDefault();
    // Display toaster message
    toast.success('Thanks for subscribing!');
    // Reset email input
    setEmail('');
  };

  return (
    <footer className="bg-gray-900 text-white py-12 mt-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row justify-between items-center">
          <div className="lg:w-1/3">
            <h2 className="text-2xl font-bold mb-4">Explore</h2>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-gray-400 transition duration-300">About Us</a></li>
              <li><a href="#" className="hover:text-gray-400 transition duration-300">Contact Us</a></li>
              <li><a href="#" className="hover:text-gray-400 transition duration-300">Terms of Service</a></li>
              <li><a href="#" className="hover:text-gray-400 transition duration-300">Privacy Policy</a></li>
            </ul>
          </div>
          <div className="lg:w-1/3 mt-8 lg:mt-0">
            <h2 className="text-2xl font-bold mb-4">Connect</h2>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-gray-400 transition duration-300">Facebook</a></li>
              <li><a href="#" className="hover:text-gray-400 transition duration-300">Twitter</a></li>
              <li><a href="#" className="hover:text-gray-400 transition duration-300">Instagram</a></li>
              <li><a href="#" className="hover:text-gray-400 transition duration-300">LinkedIn</a></li>
            </ul>
          </div>
          <div className="lg:w-1/3 mt-8 lg:mt-0">
            <h2 className="text-2xl font-bold mb-4">Subscribe</h2>
            <p className="mb-4">Subscribe to our newsletter for the latest updates.</p>
            <form className="flex" onSubmit={handleSubscribe}>
              <input 
                type="email" 
                placeholder="Your email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                className="py-2 px-4 mr-2 border border-gray-400 bg-gray-800 text-white rounded focus:outline-none focus:border-gray-500" 
              />
              <button type="submit" className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-6 rounded focus:outline-none">Subscribe</button>
            </form>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-8 pt-6 flex justify-between">
          <div className="text-sm">
            <p>© {new Date().getFullYear()} Blog Market. All rights reserved.</p>
          </div>
          <div className="flex space-x-4">
            <a href="#" className="text-white hover:text-gray-400 transition duration-300">
              <svg className="h-6 w-6 fill-current" viewBox="0 0 24 24">
                {/* Add your custom icon SVG here */}
              </svg>
            </a>
            <a href="#" className="text-white hover:text-gray-400 transition duration-300">
              <svg className="h-6 w-6 fill-current" viewBox="0 0 24 24">
                {/* Add your custom icon SVG here */}
              </svg>
            </a>
          </div>
        </div>
      </div>
      <ToastContainer />
    </footer>
  );
}

export default Footer;
