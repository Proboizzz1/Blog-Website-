import { Link, useLocation, useNavigate } from "react-router-dom";
import { BsSearch } from 'react-icons/bs';
import { FaBars, FaSun, FaMoon } from 'react-icons/fa';
import { useContext, useEffect, useState } from "react";
import Menu from "./Menu";
import { UserContext } from "../context/UserContext";

const Navbar = () => {
  const [prompt, setPrompt] = useState("");
  const [menu, setMenu] = useState(false);

  // Load initial dark mode preference from local storage
  const initialDarkMode = localStorage.getItem("darkMode") === "true";
  const [isDarkMode, setIsDarkMode] = useState(initialDarkMode);

  const navigate = useNavigate();
  const path = useLocation().pathname;

  const showMenu = () => {
    setMenu(!menu);
  };

  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode;
    setIsDarkMode(newDarkMode);
    // Store the dark mode preference in local storage
    localStorage.setItem("darkMode", newDarkMode);
  };

  const { user } = useContext(UserContext);

  useEffect(() => {
    const applyDarkMode = () => {
      if (isDarkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    };

    applyDarkMode();
  }, [isDarkMode]);

  return (
    <div className={`flex items-center justify-between px-4 md:px-8 lg:px-12 py-4 ${isDarkMode ? 'bg-gray-800 text-white' : 'bg-gray-200 text-black'}`}>
      <h1 className="text-lg md:text-xl font-extrabold flex items-center">
        <Link to="/">Blog Market</Link>
        {/* Dark Mode and Light Mode toggles */}
        <button onClick={toggleDarkMode} className="ml-4 focus:outline-none">
          {isDarkMode ? <FaSun /> : <FaMoon />}
        </button>
      </h1>
      {path === "/" && (
        <div className="flex justify-center items-center space-x-2">
          <input onChange={(e) => setPrompt(e.target.value)} className="px-3 py-1 rounded-lg focus:outline-none" placeholder="Search a post" type="text" />
          <button onClick={() => navigate(prompt ? `?search=${prompt}` : navigate("/"))} className="p-2 rounded-lg bg-blue-500 text-white">
            <BsSearch />
          </button>
        </div>
      )}
      <div className="hidden md:flex items-center justify-center space-x-4">
        {user ? <Link to="/write" className="text-blue-500">Write</Link> : <Link to="/login" className="text-blue-500">Login</Link>}
        {user ? (
          <div onClick={showMenu} className="relative cursor-pointer">
            <FaBars />
            {menu && <Menu />}
          </div>
        ) : (
          <Link to="/register" className="text-blue-500">Register</Link>
        )}
      </div>
      <div onClick={showMenu} className="md:hidden text-lg cursor-pointer">
        <FaBars />
        {menu && <Menu />}
      </div>
    </div>
  );
}

export default Navbar;
